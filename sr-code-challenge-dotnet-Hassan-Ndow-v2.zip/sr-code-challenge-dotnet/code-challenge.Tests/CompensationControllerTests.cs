using challenge.Controllers;
using challenge.Data;
using challenge.Models;
using Microsoft.AspNetCore;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.TestHost;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using code_challenge.Tests.Integration.Extensions;

using System;
using System.IO;
using System.Net;
using System.Net.Http;
using code_challenge.Tests.Integration.Helpers;
using System.Text;

namespace code_challenge.Tests.Integration
{
    [TestClass]
    public class CompensationControllerTests
    {
        private static HttpClient _httpClient;
        private static TestServer _testServer;

        [ClassInitialize]
        public static void InitializeClass(TestContext context)
        {
            _testServer = new TestServer(WebHost.CreateDefaultBuilder()
                .UseStartup<TestServerStartup>()
                .UseEnvironment("Development"));

            _httpClient = _testServer.CreateClient();
        }

        [ClassCleanup]
        public static void CleanUpTest()
        {
            _httpClient.Dispose();
            _testServer.Dispose();
        }

        [TestMethod]
        public void CreateCompensation_Returns_Created()
        {
            // Arrange
            var employee = new Employee()
            {
                Department = "Development",
                FirstName = "Hassan",
                LastName = "Ndow",
                Position = "Software Engineer"
            };

            Compensation compensation = new Compensation()
            {
                Employee = employee,
                Salary = 130000,
                EffectiveDate = new DateTimeOffset(new DateTime(2022, 5, 1))
            };


            var requestContent = new JsonSerialization().ToJson(compensation);

            // Execute
            var postRequestTask = _httpClient.PostAsync("api/compensation",
               new StringContent(requestContent, Encoding.UTF8, "application/json"));
            var response = postRequestTask.Result;

            // Assert
            Assert.AreEqual(HttpStatusCode.Created, response.StatusCode);

            var newCompensation = response.DeserializeContent<Compensation>();
            Assert.IsNotNull(newCompensation.CompensationId);
            Assert.IsNotNull(newCompensation.Employee.EmployeeId);
            Assert.AreEqual(compensation.Salary, compensation.Salary);
            Assert.AreEqual(compensation.EffectiveDate.Year, compensation.EffectiveDate.Year);
            Assert.AreEqual(compensation.EffectiveDate.Month, compensation.EffectiveDate.Month);
            Assert.AreEqual(compensation.EffectiveDate.Day, compensation.EffectiveDate.Day);
            Assert.AreEqual(employee.FirstName, newCompensation.Employee.FirstName);
            Assert.AreEqual(employee.LastName, newCompensation.Employee.LastName);
            Assert.AreEqual(employee.Department, newCompensation.Employee.Department);
            Assert.AreEqual(employee.Position, newCompensation.Employee.Position);
        }

        [TestMethod]
        public void GetCompensationById_Returns_Ok()
        {

            // Arrange
            var employeeId = "a7839309-3348-463b-a7e3-5de1c168beb3";
            var expectedSalary = 130000;
            var expectedYear = 2022;
            var expectedMonth = 5;
            var expectedDay = 1;

            // Execute
            var getRequestTask = _httpClient.GetAsync($"api/compensation/{employeeId}");
            var response = getRequestTask.Result;

            // Assert
            Assert.AreEqual(HttpStatusCode.OK, response.StatusCode);

            var compensation = response.DeserializeContent<Compensation>();
            Assert.AreEqual(expectedSalary, compensation.Salary);
            Assert.AreEqual(expectedYear, compensation.EffectiveDate.Year);
            Assert.AreEqual(expectedMonth, compensation.EffectiveDate.Month);
            Assert.AreEqual(expectedDay, compensation.EffectiveDate.Day);
        }
    }
}
