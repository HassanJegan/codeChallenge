﻿using System;
using System.Linq;
using System.Threading.Tasks;
using challenge.Models;
using Microsoft.Extensions.Logging;
using challenge.Data;

namespace challenge.Repositories
{
    //Creates Repository for Compensation query related methods
    public class CompensationRespository : ICompensationRepository
    {
        private readonly EmployeeContext _employeeContext;
        private readonly ILogger<IEmployeeRepository> _logger;

        public CompensationRespository(ILogger<IEmployeeRepository> logger, EmployeeContext employeeContext)
        {
            _employeeContext = employeeContext;
            _logger = logger;
        }

        //adds compensation to database
        public Compensation Add(Compensation compensation)
        {
            compensation.CompensationId = Guid.NewGuid().ToString();
            _employeeContext.Compensations.Add(compensation);
            return compensation;
        }

        //retrieves compensation by employee id from database
        public Compensation GetById(string id)
        {
            return _employeeContext.Compensations.FirstOrDefault(e => e.Employee != null && e.Employee.EmployeeId == id);
        }

        //saves the changes to the database
        public Task SaveAsync()
        {
            return _employeeContext.SaveChangesAsync();
        }
    }
}
