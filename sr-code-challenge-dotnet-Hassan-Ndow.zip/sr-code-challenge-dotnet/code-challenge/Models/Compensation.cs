﻿using System;

namespace challenge.Models
{
    public class Compensation
    {
        public string CompensationId { get; set; }
        public Employee Employee { get; set; }
        public double Salary { get; set; }
        public DateTimeOffset EffectiveDate { get; set; } //uses DateTimeOffset since end users can be operating on different timezones
    }
}
